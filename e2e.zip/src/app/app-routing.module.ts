import { NgModule } from '@angular/core';
import { Routes, RouterModule,CanActivate } from '@angular/router';
import { LoginComponent } from './login/login.component'
import { CadastroComponent } from './cadastro/cadastro.component'
import { CasaComponent } from './casa/casa.component'
import { HomeComponent } from './home/home.component'
import { OddsComponent } from './odds/odds.component';
import { OverviewComponent } from './overview/overview.component';
import { NextgamesComponent } from './nextgames/nextgames.component';
import { JogosComponent } from './hoje/jogos/jogos.component';
import { ArtilheiroComponent } from './hoje/artilheiros/artilheiro.component';
import { CalculadoraComponent } from './hoje/calculadora/calculadora.component';
import { RankingComponent } from './hoje/ranking/ranking.component';
import { MaximaComponent } from './maxima/maxima.component';
import { HorarioComponent } from './horario/horario.component';
import { LogoutComponent } from './logout/logout.component';
import { PagamentoComponent } from './pagamento/pagamento.component';
import { RespostaPagamentoComponent } from './respostapagamento/respostapagamento.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'cadastro', component: CadastroComponent },
  { path: 'bookies', component: CasaComponent },
  { path: 'home', component: HomeComponent },
  { path: 'odds', component: OddsComponent },
  { path: 'overview/:bookie/:season', component: OverviewComponent },
  { path: 'nextgames/:bookie/:season', component: NextgamesComponent },
  { path: 'hoje/jogos', component: JogosComponent },
  { path: 'hoje/artilheiro', component: ArtilheiroComponent },
  { path: 'hoje/calculadora', component: CalculadoraComponent },
  { path: 'hoje/ranking', component: RankingComponent },
  { path: 'maxima', component: MaximaComponent },
  { path: 'horario/:bookie/:season', component: HorarioComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'renewal', component: PagamentoComponent },
  { path: 'pagamento-resposta/:pacote', component: RespostaPagamentoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [LoginComponent, CadastroComponent];
