import { Component, OnInit } from '@angular/core';
import { DateAdapter } from '@angular/material/core';
import { ApiService } from '../shared/services/api.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-pagamento',
  templateUrl: './pagamento.component.html',
  styleUrls: ['./pagamento.component.css']
})
export class PagamentoComponent implements OnInit {
  globa = {id: ''}
  constructor(private dateAdapter: DateAdapter<Date>, private apiService:ApiService, private router: Router, private route: ActivatedRoute) {
  }

  formShowing:boolean = false;

  errorMessage:string;

  callMeli(pacote){

    var item = {}


    if(pacote == 1){
      item = {
        "title" : "BETANO | ADESÃO + 1 MÊS",
        "description" : "BETANO | ADESÃO + 1 MÊS",
        "quantity": 1,
        "currency_id": "BRL",
        "unit_price": 30
      }
    }

    var teste = {
      "items": [ 
        item 
      ],   
      "back_urls": { 
          "failure" : "https://www.analisebetmilhao.com.br/pagamento-resposta/"+pacote,
          "pending" : "https://www.analisebetmilhao.com.br/pagamento-resposta/"+pacote,
          "success" : "https://www.analisebetmilhao.com.br/pagamento-resposta/"+pacote
      },
      "auto_return": "approved"
  }

    this.apiService.createPreferences(teste).subscribe(
      data  => {
        console.log(data)
        //window.location.href = data['init_point']; 
        window.location.href = data['init_point']; 
      },
      error => {
        console.log(error)
      }
    );
    
  }
  

  ngOnInit(): void {
    
  }

 
}
